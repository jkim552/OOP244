/* Citation and Sources...
Final Project Milestone 6
Module: Parking
Filename: Parking.h
Version 1.0
Author John Kim
Revision History
-----------------------------------------------------------
Date Reason
2020/07/13 Preliminary release
2020/07/28 Reused on M6
-----------------------------------------------------------
I have done all the coding by myself and only copied the code
that my professor provided to complete my workshops and assignments.
-----------------------------------------------------------*/
#ifndef SDDS_PARKING_H
#define SDDS_PARKING_H

#include "Menu.h"
#include "Utils.h"
#include "Vehicle.h"
namespace sdds {
	const int MaxNumSpot = 100;
	class Parking {
	private:
		int numOfSpots;
		Vehicle parkingSpots[MaxNumSpot];
		int numOfParkedV;

		char* filename;
		Menu* parking;
		Menu* vehicle;
		bool isEmpty() const;
		void displayStatus() const;
		void parkVehicle() const;
		void returnVehicle() const;
		void listParked() const;
		bool closeParking() const;
		bool exitParking() const;
		bool loadFile() const;
		void saveFile() const;
	public:
		Parking(const char* nam, int num);
		~Parking();
		Parking(const Parking& pk) = delete;
		Parking& operator=(const Parking& pk) = delete;
		int run() const;

	};

}


#endif